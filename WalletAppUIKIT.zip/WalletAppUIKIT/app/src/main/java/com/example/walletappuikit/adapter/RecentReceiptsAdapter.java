package com.example.walletappuikit.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.walletappuikit.R;
import com.example.walletappuikit.model.RecentReceiptsModel;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecentReceiptsAdapter extends RecyclerView.Adapter<RecentReceiptsAdapter.ViewHolder> {

    Context context;
    ArrayList<RecentReceiptsModel> list;

    public RecentReceiptsAdapter(Context context, ArrayList<RecentReceiptsModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recent_receipts,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        RecentReceiptsModel model = list.get(position);

        holder.img_sendmoney.setImageResource(model.getImg_sendmoney());

        holder.tv_sendmoney.setText(model.getTv_sendmoney());



    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView img_sendmoney ;
        TextView tv_sendmoney;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img_sendmoney = itemView.findViewById(R.id.img_sendmoney);

            tv_sendmoney = itemView.findViewById(R.id.tv_sendmoney);

        }
    }
}
