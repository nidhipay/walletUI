package com.example.walletappuikit.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.walletappuikit.R;

public class OnboardingTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding_two);
    }
}
