package com.example.walletappuikit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CircularProgressBar circularProgressBar = findViewById(R.id.pb_one);
       // Set Progress
        circularProgressBar.setProgress(50f);
       // or with animation
        circularProgressBar.setProgressWithAnimation(50f, Long.valueOf(3000)); // =3s

        CircularProgressBar circularProgressBarTwo = findViewById(R.id.pb_two);
        // Set Progress
        circularProgressBarTwo.setProgress(60f);
        // or with animation
        circularProgressBarTwo.setProgressWithAnimation(60f, Long.valueOf(3000)); // =1s

        circularProgressBarTwo.setProgressDirection(CircularProgressBar.ProgressDirection.TO_LEFT);




    }
}
