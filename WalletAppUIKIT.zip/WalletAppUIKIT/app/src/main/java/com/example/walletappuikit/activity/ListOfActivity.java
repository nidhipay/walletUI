package com.example.walletappuikit.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.walletappuikit.MainActivity;
import com.example.walletappuikit.R;

public class ListOfActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of);
    }

    public void SplashScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, SpashScreen.class));
    }


    public void OnBoardingScreenThree(View view) {

        startActivity(new Intent(ListOfActivity.this, OnboardingThree.class));
    }

    public void OnBoardingScreenTwo(View view) {

        startActivity(new Intent(ListOfActivity.this, OnboardingTwo.class));
    }

    public void OnBoardingScreenOne(View view) {

        startActivity(new Intent(ListOfActivity.this, OnboardingOne.class));
    }

    public void WatchTutorialScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, WatchTutorialScreen.class));
    }

    public void SignUpScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, SignUpScreen.class));
    }

    public void PhoneNumberRegistrationScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, PhoneNumberRegistrationScreen.class));
    }

    public void AccountCreatedScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, AccountCreatedScreen.class));
    }

    public void SignInScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, SignInScreen.class));

    }

    public void AddCardScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, AddCardScreen.class));
    }

    public void HomeScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, MainActivity.class));
    }

    public void WalletScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, WalletScreen.class));
    }

    public void SearchNearbyScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, SearchNearbyScreen.class));
    }

    public void SendMoneyScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, SendMoneyScreen.class));
    }

    public void VarifyAccountScreen(View view) {

        startActivity(new Intent(ListOfActivity.this, VarifyAccountScreen.class));
    }
}