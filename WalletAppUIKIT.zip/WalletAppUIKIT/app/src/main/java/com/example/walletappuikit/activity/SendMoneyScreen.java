package com.example.walletappuikit.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.walletappuikit.R;
import com.example.walletappuikit.adapter.RecentReceiptsAdapter;
import com.example.walletappuikit.model.RecentReceiptsModel;
import com.example.walletappuikit.model.SendInvitationModel;

import java.util.ArrayList;

public class SendMoneyScreen extends AppCompatActivity {

    private ArrayList<RecentReceiptsModel> list;
    private RecyclerView recyclerView;
    private RecentReceiptsAdapter mAdapter;

    Integer img1[] = {R.drawable.sendme_imgone, R.drawable.sendme_imgtwo, R.drawable.sendme_imgthree, R.drawable.sendme_imgfour};
    String name[] = {"Micheal", "Billy", "Mark", "James"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money_screen);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        list = new ArrayList<>();

        for (int i = 0; i < img1.length; i++) {
            RecentReceiptsModel beanClassForRecyclerView_contacts = new RecentReceiptsModel(img1[i], name[i]);
            list.add(beanClassForRecyclerView_contacts);
        }
        mAdapter = new RecentReceiptsAdapter(SendMoneyScreen.this, list);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(SendMoneyScreen.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
    }
}
