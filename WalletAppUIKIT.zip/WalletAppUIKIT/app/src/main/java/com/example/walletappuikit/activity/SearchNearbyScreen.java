package com.example.walletappuikit.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.walletappuikit.FragmentBottomSheetFull;
import com.example.walletappuikit.R;

public class SearchNearbyScreen extends AppCompatActivity {

    private ImageView serchicon_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_nearby_screen);

        FragmentBottomSheetFull fragment = new FragmentBottomSheetFull();
        fragment.show(getSupportFragmentManager(), fragment.getTag());

        serchicon_img = findViewById(R.id.serchicon_img);

        serchicon_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                FragmentBottomSheetFull fragment = new FragmentBottomSheetFull();
                fragment.show(getSupportFragmentManager(), fragment.getTag());
            }
        });
    }
}
